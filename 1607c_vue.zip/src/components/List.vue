<template lang="html">
    <div>
        <my-header :title="title"></my-header>

        <div class="content">
            <ul>
                <li v-for="item in users">
                  <img :src="item.avatar_url"/>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import MyHeader from './Header'
var axios = require('axios')

export default {
  data:function(){
    return{
      title:'分类',
      products:[
        {id:0,name:'milk',price:12},
        {id:1,name:'milk1',price:132},
        {id:2,name:'milk2',price:122},
        {id:3,name:'milk3',price:152},
        {id:4,name:'milk4',price:152}
      ],
      users:[]
    }
  },
  components:{
    'my-header':MyHeader
  },
  mounted:function(){

    var that = this;
    axios.get('https://api.github.com/users')
    .then(function (response) {
      console.log(response);
      return response.data
    })
    .then(function(json){
      // console.log(this)
        that.users = json;
    })
    .catch(function (error) {
      console.log(error);
    });

  }
}
</script>

<style lang="css">

.content{
  margin-top: 45px;
}
ul{list-style:none;margin: 0;padding: 0}
</style>
