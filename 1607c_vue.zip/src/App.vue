<template>
  <div id="app">

    <ul  class="nav">
      <li>
        <router-link to="/home">home</router-link>
      </li>
      <li>
        <router-link to="/list">list</router-link>
      </li>
    </ul>
    <router-view></router-view>
  </div>
</template>

<script>



export default {
  name: 'app'
}
</script>

<style>

html,body{
  width: 100%;height: 100%;

}
body{
  background-color: #eee;
  padding: 0;margin: 0;
  overflow-x: hidden;
  overflow-y: scroll;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  /*margin-top: 60px;*/
}

a{
  text-decoration: none;
}
a:link{
  color: #000;
}
a:active{
    color: #000;
}

.nav{
  padding: 0;
  margin: 0;
  width: 100%;
  height: 45px;
  list-style: none;
  position: fixed;
  bottom: 0;
  left: 0;
  background-color: #fff;
  display: flex;
}
.nav li{
  flex:1;
  text-align: center;
  line-height: 45px;
}

</style>
